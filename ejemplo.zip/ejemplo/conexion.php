<?php 
$db = new mysqli('localhost', 'root', '', 'ejemplo');
$titulo = "Ejemplo en la Clase";
?>